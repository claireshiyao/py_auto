# author by claire
from selenium.webdriver.common.by import By


class HomePageLocs:
    # 退出链接
    exit_link = (By.XPATH, '//a[text()="退出"]')
