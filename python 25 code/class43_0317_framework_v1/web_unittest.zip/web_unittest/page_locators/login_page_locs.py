# author by claire
from selenium.webdriver.common.by import By


class LoginPageLocs:
    # 用户名输入框
    user_input = (By.XPATH, '//input[@name="phone"]')
    # 密码输入框
    passwd_input = (By.XPATH, '//input[@name="password"]')
    # 登陆按钮
    login_button = (By.TAG_NAME, 'button')
    # 登录页面提示框
    login_hint = (By.XPATH, '//div[@class= "form-error-info"]')
    # 账号或密码错误提示框
    wrong_passwd_hint = (By.XPATH, '//div[@class ="layui-layer-content" and contains(text(), "帐号或密码错误")]')
    # 验证码错误提示框
    wrong_captcha_hint = (By.XPATH, '//div[@class ="layui-layer-content" and contains(text(), "验证码错误")]')