# author by claire

import unittest

from selenium import webdriver

from web_unittest.page_objects.home_page import HomePage
from web_unittest.page_objects.login_page import LoginPage
from web_unittest.test_datas import global_datas as gds
from web_unittest.test_datas import login_datas as lds
from web_unittest.test_datas.login_datas import cases, case_wrong_passwd as wrong
import ddt


@ddt.ddt
class TestLogin(unittest.TestCase):

    def setUp(self) -> None:
        self.driver = webdriver.Chrome()
        self.driver.get(gds.login_url)
        self.driver.maximize_window()

    def tearDown(self) -> None:
        self.driver.quit()

    def test_login_success(self):
        LoginPage(self.driver).login(*lds.login_success_data)
        self.assertTrue(HomePage(self.driver).get_element_exists())

    @ddt.data(*cases)
    def test_login_failed(self, case):
        lp = LoginPage(self.driver)
        lp.login(case["user"], case["passwd"])
        self.assertEqual(case["check"], lp.get_error_msg())

    def test_login_failed_wrong_passwd(self):
        lp = LoginPage(self.driver)
        lp.login(wrong["user"], wrong["passwd"])
        self.assertEqual(wrong["check"], lp.get_error_hint())

if __name__ == '__main__':
    unittest.main


