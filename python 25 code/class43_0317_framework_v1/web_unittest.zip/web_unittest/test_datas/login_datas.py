# author by claire

login_success_data = ('13760246701', 'python')

cases = [
        {"user": "", "passwd": "python", "check": "请输入手机号"},
        {"user": "13760246701", "passwd": "", "check": "请输入密码"},
        {"user": "1376024670", "passwd": "python", "check": "请输入正确的手机号"},
    ]

case_wrong_passwd = {"user": "13760246701", "passwd": "pytho", "check": "帐号或密码错误!"}
