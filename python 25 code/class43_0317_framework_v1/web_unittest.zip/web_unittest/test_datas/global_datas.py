# author by claire

base_url = 'http://120.78.128.25:8765/'
login_url = base_url + 'Index/login.html'
