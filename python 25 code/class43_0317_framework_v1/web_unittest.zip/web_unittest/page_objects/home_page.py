# author by claire
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from web_unittest.page_locators.home_page_locs import HomePageLocs as locs


class HomePage:

    def __init__(self, driver:WebDriver):
        self.driver = driver

    def get_element_exists(self):
        try:
            WebDriverWait(self.driver, 20).until(expected_conditions.visibility_of_element_located(locs.exit_link))
        except:
            return False
        else:
            return True


