# author by claire
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from web_unittest.page_locators.login_page_locs import LoginPageLocs as locs


class LoginPage:

    def __init__(self, driver: WebDriver):
        self.driver = driver

    def login(self, username, passwd):
        WebDriverWait(self.driver, 20).until(expected_conditions.visibility_of_element_located(locs.login_button))
        self.driver.find_element(*locs.user_input).send_keys(username)
        self.driver.find_element(*locs.passwd_input).send_keys(passwd)
        self.driver.find_element(*locs.login_button).click()

    def get_error_msg(self):
        WebDriverWait(self.driver, 20).until(expected_conditions.visibility_of_element_located(locs.login_hint))
        eles = self.driver.find_elements(*locs.login_hint)
        print(eles)
        if len(eles) == 1:
            return eles[0].text
        elif len(eles) > 1:
            eles_list = []
            for i in eles:
                eles_list.append(i.text)
            return eles_list

    def get_error_hint(self):
        WebDriverWait(self.driver, 20).until(expected_conditions.visibility_of_element_located(locs.wrong_passwd_hint))
        eles = self.driver.find_elements(*locs.wrong_passwd_hint)
        print(eles)
        if len(eles) == 1:
            return eles[0].text
        elif len(eles) > 1:
            eles_list = []
            for i in eles:
                eles_list.append(i.text)
            return eles_list




